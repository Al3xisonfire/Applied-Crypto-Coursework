import os

NTRU_N   = 677
NTRU_N32 = 704
NTRU_Q   = 2048

NAMESPACE = os.environ.get('NTRU_NAMESPACE', '')
