## NTRU

NTRU is a submission to the second round of [NIST's Post-Quantum Cryptography
project](https://csrc.nist.gov/Projects/Post-Quantum-Cryptography/Round-2-Submissions).
It is a merger of the first round NTRUEncrypt and NTRU-HRSS-KEM submissions. See [ntru.org](https://ntru.org) for more information.
