import os

NTRU_N   = 821
NTRU_N32 = 832
NTRU_Q   = 4096

NAMESPACE = os.environ.get('NTRU_NAMESPACE', '')
