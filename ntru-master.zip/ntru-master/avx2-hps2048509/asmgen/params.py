import os

NTRU_N   = 509
NTRU_N32 = 512
NTRU_Q   = 2048

NAMESPACE = os.environ.get('NTRU_NAMESPACE', '')
