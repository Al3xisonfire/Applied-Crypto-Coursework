Léo Ducas,
Eike Kiltz,
Tancrède Lepoint,
Vadim Lyubashevsky,
Gregor Seiler,
Peter Schwabe,
Damien Stehlé
